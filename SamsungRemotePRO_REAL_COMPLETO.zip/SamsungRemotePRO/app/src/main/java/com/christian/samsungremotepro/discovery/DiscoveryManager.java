package com.christian.samsungremotepro.discovery;
import android.content.Context; import android.net.wifi.WifiManager; import java.net.*; import java.util.*;
public class DiscoveryManager {
 public interface Callback{ void onFound(DiscoveredTv tv); void onDone(); void onError(String error); }
 public static void search(Context ctx, Callback cb){ new Thread(() -> { WifiManager.MulticastLock lock=null; try{ WifiManager wm=(WifiManager)ctx.getApplicationContext().getSystemService(Context.WIFI_SERVICE); if(wm!=null){ lock=wm.createMulticastLock("ssdp"); lock.acquire(); }
   Set<String> seen=new HashSet<>(); DatagramSocket sock=new DatagramSocket(); sock.setSoTimeout(900); String msg="M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 2\r\nST: ssdp:all\r\n\r\n";
   byte[] data=msg.getBytes(); DatagramPacket p=new DatagramPacket(data,data.length, InetAddress.getByName("239.255.255.250"),1900); sock.send(p); long end=System.currentTimeMillis()+6500;
   while(System.currentTimeMillis()<end){ try{ byte[] buf=new byte[4096]; DatagramPacket res=new DatagramPacket(buf,buf.length); sock.receive(res); String raw=new String(res.getData(),0,res.getLength()); String lower=raw.toLowerCase(Locale.US); if(lower.contains("samsung") || lower.contains("tizen") || lower.contains("tv")){ String ip=res.getAddress().getHostAddress(); if(seen.add(ip)){ cb.onFound(new DiscoveredTv(extractName(raw), ip, raw)); } } }catch(SocketTimeoutException ignored){} }
   sock.close(); cb.onDone(); }catch(Exception e){ cb.onError(e.getMessage()); } finally { if(lock!=null && lock.isHeld()) lock.release(); } }).start(); }
 private static String extractName(String raw){ for(String line: raw.split("\r?\n")){ String l=line.toLowerCase(Locale.US); if(l.startsWith("server:")) return line.substring(7).trim(); if(l.startsWith("usn:")) return line.substring(4).trim(); } return "Samsung TV detectada"; }
}
