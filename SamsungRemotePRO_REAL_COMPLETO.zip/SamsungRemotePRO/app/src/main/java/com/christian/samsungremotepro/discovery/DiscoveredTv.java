package com.christian.samsungremotepro.discovery;
public class DiscoveredTv { public final String name, ip, raw; public DiscoveredTv(String name, String ip, String raw){ this.name=name; this.ip=ip; this.raw=raw; } public String toString(){ return name + " - " + ip; } }
