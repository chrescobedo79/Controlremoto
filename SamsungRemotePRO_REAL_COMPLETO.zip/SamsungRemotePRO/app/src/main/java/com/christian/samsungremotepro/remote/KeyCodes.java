package com.christian.samsungremotepro.remote;
public final class KeyCodes {
    private KeyCodes() {}
    public static final String POWER="KEY_POWER", HOME="KEY_HOME", MENU="KEY_MENU", BACK="KEY_RETURN", EXIT="KEY_EXIT";
    public static final String UP="KEY_UP", DOWN="KEY_DOWN", LEFT="KEY_LEFT", RIGHT="KEY_RIGHT", ENTER="KEY_ENTER";
    public static final String VOL_UP="KEY_VOLUP", VOL_DOWN="KEY_VOLDOWN", MUTE="KEY_MUTE", CH_UP="KEY_CHUP", CH_DOWN="KEY_CHDOWN";
    public static final String PLAY="KEY_PLAY", PAUSE="KEY_PAUSE", STOP="KEY_STOP", FF="KEY_FF", REW="KEY_REWIND", SOURCE="KEY_SOURCE", INFO="KEY_INFO";
    public static String digit(int d){ return "KEY_" + d; }
}
