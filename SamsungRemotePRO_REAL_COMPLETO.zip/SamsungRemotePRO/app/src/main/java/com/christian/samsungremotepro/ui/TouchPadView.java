package com.christian.samsungremotepro.ui;
import android.content.*; import android.graphics.*; import android.view.*; import com.christian.samsungremotepro.remote.KeyCodes;
public class TouchPadView extends View { public interface Listener{ void onKey(String key); } private Listener listener; private Paint p=new Paint(1); private float sx,sy; private long down;
 public TouchPadView(Context c){ super(c); setMinimumHeight(dp(160)); }
 public void setListener(Listener l){ listener=l; }
 protected void onDraw(Canvas c){ super.onDraw(c); p.setStyle(Paint.Style.FILL); p.setColor(0xffeeeeee); c.drawRoundRect(0,0,getWidth(),getHeight(),dp(18),dp(18),p); p.setColor(0xff555555); p.setTextSize(dp(16)); p.setTextAlign(Paint.Align.CENTER); c.drawText("Touchpad: desliza / toca para OK", getWidth()/2f, getHeight()/2f, p); }
 public boolean onTouchEvent(android.view.MotionEvent e){ switch(e.getAction()){ case MotionEvent.ACTION_DOWN: sx=e.getX(); sy=e.getY(); down=System.currentTimeMillis(); return true; case MotionEvent.ACTION_UP: float dx=e.getX()-sx, dy=e.getY()-sy; if(Math.abs(dx)<35 && Math.abs(dy)<35 && System.currentTimeMillis()-down<500){ emit(KeyCodes.ENTER); } else if(Math.abs(dx)>Math.abs(dy)){ emit(dx>0?KeyCodes.RIGHT:KeyCodes.LEFT); } else { emit(dy>0?KeyCodes.DOWN:KeyCodes.UP); } return true; } return true; }
 private void emit(String k){ if(listener!=null) listener.onKey(k); }
 private int dp(int v){ return (int)(v*getResources().getDisplayMetrics().density); }
}
