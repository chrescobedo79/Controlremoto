package com.christian.samsungremotepro.remote;

import android.util.Base64;
import org.json.JSONObject;
import okhttp3.*;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.concurrent.TimeUnit;
import javax.net.ssl.*;

public class SamsungRemoteClient {
    public interface Listener { void onStatus(String text); void onToken(String token); }
    private OkHttpClient client; private WebSocket socket; private Listener listener; private String ip, token, appName;

    public SamsungRemoteClient(Listener listener) { this.listener = listener; this.appName = Base64.encodeToString("Samsung Remote PRO".getBytes(), Base64.NO_WRAP); }

    public void connect(String ip, String token, boolean secure) {
        this.ip=ip; this.token=token == null ? "" : token.trim();
        client = secure ? unsafeClient() : new OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).build();
        String scheme = secure ? "wss" : "ws"; String port = secure ? "8002" : "8001";
        String url = scheme + "://" + ip + ":" + port + "/api/v2/channels/samsung.remote.control?name=" + appName;
        if (!this.token.isEmpty()) url += "&token=" + this.token;
        Request request = new Request.Builder().url(url).build();
        if(listener!=null) listener.onStatus("Conectando a " + ip + " por " + scheme.toUpperCase() + "...");
        socket = client.newWebSocket(request, new WebSocketListener() {
            @Override public void onOpen(WebSocket webSocket, Response response) { if(listener!=null) listener.onStatus("Conectado. Acepta el permiso en la TV si aparece."); }
            @Override public void onMessage(WebSocket webSocket, String text) { handleMessage(text); }
            @Override public void onFailure(WebSocket webSocket, Throwable t, Response response) { if(listener!=null) listener.onStatus("Error: " + t.getMessage() + ". Prueba puerto no seguro o revisa la IP."); }
            @Override public void onClosed(WebSocket webSocket, int code, String reason) { if(listener!=null) listener.onStatus("Desconectado: " + reason); }
        });
    }

    private void handleMessage(String text){
        try { JSONObject obj = new JSONObject(text); if(obj.has("data")) { JSONObject data=obj.optJSONObject("data"); if(data!=null && data.has("token")) { token=data.getString("token"); if(listener!=null) listener.onToken(token); } } }
        catch(Exception ignored) {}
        if(listener!=null) listener.onStatus("TV: " + text);
    }

    public boolean isConnected(){ return socket != null; }
    public void disconnect(){ if(socket!=null) socket.close(1000, "User closed"); socket=null; }
    public void sendKey(String key){
        try { JSONObject params=new JSONObject(); params.put("Cmd","Click"); params.put("DataOfCmd",key); params.put("Option","false"); params.put("TypeOfRemote","SendRemoteKey");
            JSONObject root=new JSONObject(); root.put("method","ms.remote.control"); root.put("params",params); send(root); }
        catch(Exception e){ if(listener!=null) listener.onStatus("No se pudo enviar " + key + ": " + e.getMessage()); }
    }
    public void sendText(String text){
        try { for(int i=0;i<text.length();i++){ JSONObject params=new JSONObject(); params.put("Cmd","Click"); params.put("DataOfCmd",String.valueOf(text.charAt(i))); params.put("Option","false"); params.put("TypeOfRemote","SendInputString"); JSONObject root=new JSONObject(); root.put("method","ms.remote.control"); root.put("params",params); send(root); Thread.sleep(40); } }
        catch(Exception e){ if(listener!=null) listener.onStatus("Texto no enviado: " + e.getMessage()); }
    }
    public void launchApp(String appId){
        try { JSONObject params=new JSONObject(); params.put("appId", appId); params.put("action_type", "NATIVE_LAUNCH"); JSONObject root=new JSONObject(); root.put("method","ms.channel.emit"); root.put("event","ed.apps.launch"); root.put("to","host"); root.put("data", params); send(root); }
        catch(Exception e){ if(listener!=null) listener.onStatus("No se pudo abrir app: " + e.getMessage()); }
    }
    private void send(JSONObject root){ if(socket==null){ if(listener!=null) listener.onStatus("Primero conecta la TV."); return; } socket.send(root.toString()); }

    private static OkHttpClient unsafeClient(){
        try { final TrustManager[] trustAll = new TrustManager[]{ new X509TrustManager(){ public void checkClientTrusted(X509Certificate[] c,String a){} public void checkServerTrusted(X509Certificate[] c,String a){} public X509Certificate[] getAcceptedIssuers(){ return new X509Certificate[]{}; } } };
            SSLContext sc = SSLContext.getInstance("TLS"); sc.init(null, trustAll, new SecureRandom());
            return new OkHttpClient.Builder().sslSocketFactory(sc.getSocketFactory(), (X509TrustManager) trustAll[0]).hostnameVerifier((h,s)->true).pingInterval(20, TimeUnit.SECONDS).build();
        } catch(Exception e){ return new OkHttpClient(); }
    }
}
