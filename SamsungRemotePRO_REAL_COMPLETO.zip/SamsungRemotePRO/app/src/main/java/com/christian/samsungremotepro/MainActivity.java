package com.christian.samsungremotepro;

import android.app.*; import android.os.*; import android.graphics.Color; import android.view.*; import android.view.inputmethod.InputMethodManager; import android.content.*; import android.widget.*; import java.util.*;
import com.christian.samsungremotepro.remote.*; import com.christian.samsungremotepro.discovery.*; import com.christian.samsungremotepro.storage.Prefs; import com.christian.samsungremotepro.ui.TouchPadView;

public class MainActivity extends Activity implements SamsungRemoteClient.Listener {
    private LinearLayout root, logBox; private EditText ipEdit, macEdit, textEdit; private TextView status; private CheckBox secureBox; private Prefs prefs; private SamsungRemoteClient remote;
    private final Map<String,String> apps=new LinkedHashMap<>();
    public void onCreate(Bundle b){ super.onCreate(b); prefs=new Prefs(this); remote=new SamsungRemoteClient(this); seedApps(); buildUi(); }
    private void seedApps(){ apps.put("YouTube","111299001912"); apps.put("Netflix","11101200001"); apps.put("Prime Video","3201512006785"); apps.put("Disney+","3201901017640"); apps.put("Internet","org.tizen.browser"); }
    private void buildUi(){ ScrollView sv=new ScrollView(this); root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(16),dp(18),dp(16),dp(28)); sv.addView(root); setContentView(sv);
        TextView title=label("Samsung Remote PRO",26,true); root.addView(title); root.addView(label("Control remoto Wi‑Fi para Smart TV Samsung / Tizen",14,false));
        LinearLayout row=row(); ipEdit=input("IP de la TV, ej. 192.168.1.50", prefs.ip()); row.addView(ipEdit,new LinearLayout.LayoutParams(0,-2,1)); Button scan=btn("Buscar"); row.addView(scan); root.addView(row); scan.setOnClickListener(v->scanTv());
        macEdit=input("MAC para encender por Wake-on-LAN opcional", prefs.mac()); root.addView(macEdit); secureBox=new CheckBox(this); secureBox.setText("Usar conexión segura WSS puerto 8002"); secureBox.setChecked(prefs.secure()); root.addView(secureBox);
        LinearLayout cr=row(); Button connect=btn("Conectar"); Button disconnect=btn("Desconectar"); Button wol=btn("Encender WOL"); cr.addView(connect,new LinearLayout.LayoutParams(0,-2,1)); cr.addView(disconnect,new LinearLayout.LayoutParams(0,-2,1)); cr.addView(wol,new LinearLayout.LayoutParams(0,-2,1)); root.addView(cr);
        connect.setOnClickListener(v->{ savePrefs(); remote.connect(ipEdit.getText().toString().trim(), prefs.token(), secureBox.isChecked()); }); disconnect.setOnClickListener(v->remote.disconnect()); wol.setOnClickListener(v->new Thread(()->{ try{ savePrefs(); WakeOnLan.send(macEdit.getText().toString()); ui("Paquete Wake-on-LAN enviado."); }catch(Exception e){ ui("WOL error: "+e.getMessage()); }}).start());
        status=label("Estado: sin conectar",14,false); root.addView(status); addSection("Controles principales");
        addKeyRow(new String[][]{{"Power",KeyCodes.POWER},{"Home",KeyCodes.HOME},{"Back",KeyCodes.BACK},{"Source",KeyCodes.SOURCE}});
        addKeyRow(new String[][]{{"Vol +",KeyCodes.VOL_UP},{"Mute",KeyCodes.MUTE},{"Vol -",KeyCodes.VOL_DOWN},{"Info",KeyCodes.INFO}});
        addKeyRow(new String[][]{{"CH +",KeyCodes.CH_UP},{"Menu",KeyCodes.MENU},{"CH -",KeyCodes.CH_DOWN},{"Exit",KeyCodes.EXIT}});
        addSection("Navegación"); addKeyRow(new String[][]{{"↑",KeyCodes.UP}}); addKeyRow(new String[][]{{"←",KeyCodes.LEFT},{"OK",KeyCodes.ENTER},{"→",KeyCodes.RIGHT}}); addKeyRow(new String[][]{{"↓",KeyCodes.DOWN}});
        TouchPadView tp=new TouchPadView(this); tp.setListener(k->remote.sendKey(k)); root.addView(tp,new LinearLayout.LayoutParams(-1,dp(170)));
        addSection("Multimedia"); addKeyRow(new String[][]{{"Rew",KeyCodes.REW},{"Play",KeyCodes.PLAY},{"Pause",KeyCodes.PAUSE},{"FF",KeyCodes.FF},{"Stop",KeyCodes.STOP}});
        addSection("Números"); for(int r=0;r<3;r++){ String[][] rowKeys=new String[3][2]; for(int c=0;c<3;c++){ int d=r*3+c+1; rowKeys[c]=new String[]{String.valueOf(d),KeyCodes.digit(d)}; } addKeyRow(rowKeys); } addKeyRow(new String[][]{{"0",KeyCodes.digit(0)}});
        addSection("Teclado de texto"); LinearLayout tr=row(); textEdit=input("Texto para enviar a la TV",""); Button sendText=btn("Enviar texto"); tr.addView(textEdit,new LinearLayout.LayoutParams(0,-2,1)); tr.addView(sendText); root.addView(tr); sendText.setOnClickListener(v->new Thread(()->remote.sendText(textEdit.getText().toString())).start());
        addSection("Apps rápidas — dependen del modelo"); LinearLayout appRow=row(); for(String name: apps.keySet()){ Button b=btn(name); b.setOnClickListener(v->remote.launchApp(apps.get(name))); appRow.addView(b,new LinearLayout.LayoutParams(0,-2,1)); } root.addView(appRow);
        addSection("Registro"); logBox=new LinearLayout(this); logBox.setOrientation(LinearLayout.VERTICAL); root.addView(logBox); }
    private void scanTv(){ onStatus("Buscando TVs Samsung en la red..."); DiscoveryManager.search(this,new DiscoveryManager.Callback(){ public void onFound(DiscoveredTv tv){ runOnUiThread(()->{ ipEdit.setText(tv.ip); onStatus("Encontrada: "+tv); }); } public void onDone(){ ui("Búsqueda terminada."); } public void onError(String e){ ui("Error buscando: "+e); }}); }
    private void addSection(String t){ TextView v=label(t,18,true); v.setPadding(0,dp(18),0,dp(6)); root.addView(v); }
    private void addKeyRow(String[][] keys){ LinearLayout r=row(); for(String[] k:keys){ Button b=btn(k[0]); b.setOnClickListener(v->remote.sendKey(k[1])); r.addView(b,new LinearLayout.LayoutParams(0,dp(52),1)); } root.addView(r); }
    private Button btn(String t){ Button b=new Button(this); b.setText(t); b.setAllCaps(false); return b; }
    private EditText input(String hint,String val){ EditText e=new EditText(this); e.setHint(hint); e.setText(val); e.setSingleLine(true); return e; }
    private TextView label(String t,int sp,boolean bold){ TextView v=new TextView(this); v.setText(t); v.setTextSize(sp); v.setTextColor(Color.rgb(20,20,20)); if(bold) v.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); return v; }
    private LinearLayout row(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER); return l; }
    private void savePrefs(){ prefs.ip(ipEdit.getText().toString().trim()); prefs.mac(macEdit.getText().toString().trim()); prefs.secure(secureBox.isChecked()); }
    public void onStatus(String text){ ui(text); }
    public void onToken(String token){ prefs.token(token); ui("Token guardado: "+token); }
    private void ui(String text){ runOnUiThread(()->{ if(status!=null) status.setText("Estado: "+text); if(logBox!=null){ TextView l=label("• "+text,12,false); logBox.addView(l,0); } }); }
    private int dp(int v){ return (int)(v*getResources().getDisplayMetrics().density); }
}
